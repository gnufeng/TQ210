#ifndef _VAL_TQ210_H
#define _VAL_TQ210_H

#include <config.h>
#include <version.h>

#include <s5pv210.h>

#endif /* _VAL_TQ210_H */

